# ResearchOS Specification v0.1

**Status:** Working draft  
**Date:** 2026-06-29  
**Origin:** XLSForm Lab architecture work

ResearchOS is a proposed implementation-independent specification for composing research activities into transparent, auditable, interoperable digital workflows.

XLSForm Lab is the first Android implementation.

## Core sentence

Research protocols consist of context-sensitive activities that generate evidence. ResearchOS defines a reusable framework for executing those activities, validating their outputs, preserving provenance, and transporting evidence to external systems.

## Normative language

The words **MUST**, **MUST NOT**, **SHOULD**, **SHOULD NOT**, and **MAY** are used in the RFC 2119 sense.

## Contents

- `spec/00-preface.md`
- `spec/01-terminology.md`
- `spec/02-core-model.md`
- `spec/03-activities.md`
- `spec/04-context-relevance.md`
- `spec/05-evidence-artifacts.md`
- `spec/06-validation-quality.md`
- `spec/07-signals-capture.md`
- `spec/08-workflows-protocols.md`
- `spec/09-transport.md`
- `spec/10-implementation-notes.md`
- `adr/`
- `examples/`
