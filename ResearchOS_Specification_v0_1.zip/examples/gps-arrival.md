# Example: GPS Arrival

Activity: Locate

Goal: locate a household and verify arrival.

Request:

```text
capture(
  when =
    gps.accuracy_m < 5
    AND gps.distance_to_target_m < 3
    FOR 5s;

  return =
    gps.latitude,
    gps.longitude,
    gps.accuracy_m,
    compass.heading_deg,
    timestamp;

  timeout = 120s;
  override = allowed(reason_required=true)
)
```
