# ADR-0004: Transparency and Provenance

## Status

Accepted

## Decision

Transparency and provenance are first-class requirements.

## Rationale

Research-grade field data must be auditable and interpretable.

## Consequence

Dependencies, quality rules, validation, overrides and signal sources should be inspectable.
