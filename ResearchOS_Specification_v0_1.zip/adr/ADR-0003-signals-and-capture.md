# ADR-0003: Signals and Capture Engine

## Status

Proposed

## Decision

Continuous values are modelled as signals. Discrete measurements are observations produced by capture sessions.

## Rationale

This supports internal sensors, external devices, derived values and multi-signal capture rules.

## Consequence

Sensor-specific logic should migrate into providers and capture logic into a shared engine.
