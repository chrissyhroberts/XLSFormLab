# 07. Signals and Capture

Signals are continuous. Observations are discrete.

The Capture Engine transforms signals into observations.

## Signal examples

- gps.latitude
- gps.longitude
- gps.accuracy_m
- compass.heading_deg
- motion.stationary
- usb.temperature_c
- usb.humidity_percent
- light.lux

## Capture strategies

- Instant
- Manual
- Average
- Stable
- Threshold
- Trigger
- Continuous
- Multi-sample

## Example capture request

```text
capture(
  when =
    gps.accuracy_m < 5
    AND gps.distance_to_target_m < 3
    AND motion.stationary = true
    FOR 5s;

  return =
    gps.latitude,
    gps.longitude,
    gps.accuracy_m,
    compass.heading_deg;

  timeout = 60s;
  override = allowed(reason_required=true)
)
```

## Capture outcomes

- Success
- Override
- Timeout
- Cancelled
- Error

## Normative rules

1. Capture sessions MUST terminate with one outcome.
2. A capture result SHOULD include provenance.
3. Multi-signal conditions SHOULD be supported.
4. Override SHOULD be available where field conditions may prevent ideal acquisition.
