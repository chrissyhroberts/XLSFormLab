# 08. Workflows and Protocols

A protocol defines intended research work.

A workflow is an executable composition of activities.

## Workflow node

A workflow node SHOULD define:

- activity
- context inputs
- relevance rule
- dependencies
- validation rule
- expected evidence
- completion rule
- transport destination

## Completion

A protocol MAY define completion rules such as:

```text
all required activities complete
```

```text
consent complete before sampling
```

```text
sample collected requires chain-of-custody record
```

## Normative rules

1. Workflows MUST preserve ordering and dependency semantics.
2. Activities MAY be skipped due to relevance.
3. Required activities MUST produce evidence or an explicit non-completion outcome.
4. Protocol state SHOULD be inspectable at runtime.
