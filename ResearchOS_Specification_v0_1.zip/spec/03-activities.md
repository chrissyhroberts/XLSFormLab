# 03. Activities

Activities are organised around research verbs.

## Primitive activity verbs

Initial recommended verbs:

- Ask
- Locate
- Measure
- Observe
- Record
- Annotate
- Identify
- Verify
- Authenticate
- Track
- Randomise
- Calculate
- Export

## Activity families

### Ask

Structured elicitation from a human.

Includes: simple questions, surveys, consent, screening, Likert items, DCEs, best-worst scaling, ranking and attention checks.

### Locate

Establish or verify position.

Includes: GPS navigation, waypoint arrival, household location, sampling point location and indoor marker location.

### Measure

Acquire quantified evidence.

Includes: VAS, sound, light, temperature, humidity, distance, height, pressure and motion.

### Annotate

Mark, classify or enrich a visual or conceptual object.

Includes: body maps, lesion maps, image annotation, map annotation and timeline annotation.

### Verify

Establish that a condition, identity, protocol state or data state is acceptable.

Includes: protocol completeness, eligibility, witness confirmation, GPS arrival and data review.

## Capability

A capability is an implementation package for one or more activities.

A capability MUST declare:

- ID
- name
- activity verb or verbs
- status
- settings
- dependencies
- evidence outputs
- transport support
