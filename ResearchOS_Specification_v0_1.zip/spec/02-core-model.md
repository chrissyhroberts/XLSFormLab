# 02. Core Model

ResearchOS models research as:

```text
Protocol
  -> Workflow
      -> Activity
          -> Session
              -> Evidence
                  -> Artifact
                      -> Transport
```

Additional engines operate across the model:

```text
Context -> Relevance -> Activity Session -> Evidence -> Validation -> Quality -> Provenance -> Transport
```

## Core rules

1. A protocol MUST define or reference one or more activities.
2. An activity MUST declare what evidence it can produce.
3. A session MUST terminate in exactly one terminal state.
4. Evidence MUST carry sufficient identity to be traced to its generating activity and session.
5. Transport MUST NOT be required for evidence to exist.
6. Validation failure MUST either block transport or be explicitly recorded as accepted by override.
7. Relevance MUST be evaluated against context.
8. Provenance SHOULD be preserved whenever evidence is generated.
