# 09. Transport

Transport adapters move artifacts to external systems.

Transport targets may include:

- ODK Central
- KoBo
- REDCap
- SQL
- FHIR
- OpenMRS
- JSON API
- local file
- S3/object storage
- SharePoint
- QR
- NFC
- clipboard

## ODK

ODK integration may use:

- appearance column
- intent column
- Android Intent URI

These MUST be treated as distinct transport encodings.

## Round trip

A transport string SHOULD be parseable back into a request where practical.

This enables:

```text
generate -> paste into XLSForm -> re-import -> edit -> export
```

## Normative rules

1. Transport MUST NOT define the internal evidence model.
2. Transport adapters SHOULD be replaceable.
3. Capabilities MUST NOT contain transport-specific logic unless explicitly unavoidable.
