package com.example.xlsformlab.platform

import android.content.Context
import android.content.ContextWrapper
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

object BiometricAuthHelper {

    fun canAuthenticate(
        context: Context,
        allowDeviceCredential: Boolean
    ): Boolean {
        val authenticators = if (allowDeviceCredential) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else {
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        }

        return BiometricManager
            .from(context)
            .canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun authenticate(
        context: Context,
        title: String,
        subtitle: String,
        description: String,
        cancelText: String,
        confirmationRequired: Boolean,
        allowDeviceCredential: Boolean,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit
    ) {
        val activity = context.findFragmentActivity()

        if (activity == null) {
            onFailure("No FragmentActivity available for biometric prompt.")
            return
        }

        val authenticators = if (allowDeviceCredential) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else {
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        }

        val canAuthenticate = BiometricManager
            .from(context)
            .canAuthenticate(authenticators)

        if (canAuthenticate != BiometricManager.BIOMETRIC_SUCCESS) {
            onFailure("Biometric authentication is not available on this device.")
            return
        }

        val promptInfoBuilder = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setConfirmationRequired(confirmationRequired)
            .setAllowedAuthenticators(authenticators)

        if (subtitle.isNotBlank()) {
            promptInfoBuilder.setSubtitle(subtitle)
        }

        if (description.isNotBlank()) {
            promptInfoBuilder.setDescription(description)
        }

        if (!allowDeviceCredential) {
            promptInfoBuilder.setNegativeButtonText(
                cancelText.ifBlank { "Cancel" }
            )
        }

        val prompt = BiometricPrompt(
            activity,
            ContextCompat.getMainExecutor(context),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(
                    result: BiometricPrompt.AuthenticationResult
                ) {
                    onSuccess()
                }

                override fun onAuthenticationError(
                    errorCode: Int,
                    errString: CharSequence
                ) {
                    onFailure(errString.toString())
                }

                override fun onAuthenticationFailed() {
                    onFailure("Authentication failed.")
                }
            }
        )

        prompt.authenticate(promptInfoBuilder.build())
    }
}

private fun Context.findFragmentActivity(): FragmentActivity? {
    var current: Context? = this

    while (current is ContextWrapper) {
        if (current is FragmentActivity) {
            return current
        }
        current = current.baseContext
    }

    return null
}
